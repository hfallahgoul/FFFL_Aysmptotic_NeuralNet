# -*- coding: utf-8 -*-
"""
Created on Fri Oct 18 11:23:24 2019

@author: vfra0001
"""

#%%
import numpy as np
import numpy.random as npRnd
import numpy.matlib as mlb
import matplotlib.pyplot as plt
import scipy.stats as stats
import scipy.interpolate as interpolate
import pandas as pd


from AuxilliaryFunctions import theSigmoid1
from AuxilliaryFunctions import theSigmoid2
from AuxilliaryFunctions import theSigmoid3
from AuxilliaryFunctions import theSigmoidSine1
from AuxilliaryFunctions import theSigmoidSine2
from AuxilliaryFunctions import theSigmoidSine3
from AuxilliaryFunctions import fluctuating
from AuxilliaryFunctions import nondiff
from AuxilliaryFunctions import feedForwardNetwork

#%% Main Program (Input Part)
    
npRnd.seed(1)

# variable part is responsible for the name of the folder in which the neural network weights are saved.
part = 'part2'

# variable thef0Name is responsible for the name of weight-storing folder, and also for the function f0 of the simulation
thef0Name = 'fluctuating'

asymptoticNormal = True
asymptoticNormalSS = 200

# the variable here is the number of iterations performed in the loop below
iterationRange = 4+1

#batch and epochs are created for training purpose only
batchSize = 32
epochSize = 32

# the folder for storing weights is dependent on variable "part". If part==part2, then we use f0 listed in Shen et al (2019)
# Otherwise, we use our own modification of sigmoid functions.
if part=='part1':
    theFolder = 'Sigmoids and Its Variations'
if part=='part2':
    theFolder = 'Shen et al'

#%% The functions involved for the simulation of sigmoid function with some variation
if part=='part1':
    if (thef0Name == 'sigmoid1'):
        plottingName = r'$5\sigma(9x-2) - 3\sigma(2-9x) + 1$'
    if (thef0Name == 'sigmoid2'):
        plottingName = r'$8\sigma(9x-2) - 2\sigma(2-9x) + 5$'
    if (thef0Name == 'sigmoid3'):
        plottingName = r'$18\sigma(9x-2) - 12\sigma(2-9x) + 5$'
    if (thef0Name == 'sigmoidSine1'):
        plottingName = r'$18\sigma(9x-2) - 12\sigma(2-9x) + 5\sin(8 \pi x)$'
    if (thef0Name == 'sigmoidSine2'):
        plottingName = r'$18\sigma(9x-2) - 12\sigma(2-9x) + 10\sin(16 \pi x)$'
    if (thef0Name == 'sigmoidSine3'):
        plottingName = r'$12\sigma(2-9x) - 18\sigma(9x-2) + 10\sin(16 \pi x)$'
    

#%% The functions here are based on Shen et al (2019)
if part=='part2':
    if (thef0Name == 'fluctuating'):
        plottingName = r'$\sin(2 \pi x) + \frac{1}{3}\cos(3 \pi x + 3)$'
    if (thef0Name == 'nondiff'):
        plottingName = r'$-8(x - \frac{1}{2})\mathbb{1}_{\{0 \leq x \leq 0.5\}} + 10\sqrt{x-\frac{1}{2}}(2 - x)\mathbb{1}_{\{0.5 < x \leq 1\}}$'

#%% if activation choice is 1, then we use ReLU network. Otherwise we use network with sigmoid activation function
activationChoice = 1
if activationChoice==1:
    activationFunction='relu'
    pass
elif activationChoice==2:
    activationFunction='sigmoid'
    L = 1
    pass

#if thef0Name=='sigmoidSine1':
#    iterationRange = 7
#else:
#    iterationRange = 5
#    pass
nSample = []

# For this time, please set goTraining=True. Although some files have been saved, it is recommended to save again as the training process is fast.
goTraining = True

# The range of the iteration indicates the number of sample, from 2000, 5000, 20000, 50000, 200000 and 500000
for iterator in range(1,iterationRange):
    
    # iterator here is directly related to the number of samples of the generated data.
    if iterator==1:
        nSample.append(2000)
    elif iterator==2:
        nSample.append(5000)
    elif iterator==3:
        nSample.append(20000)
    elif iterator==4:
        nSample.append(50000)
    elif iterator==5:
        nSample.append(200000)
    elif iterator==6:
        nSample.append(500000)
        pass
    
    
    print('Sample Size = '+str(nSample[iterator-1]))
    print('')
    
    
    #This is the data generating process
    x = npRnd.uniform(0.0,1.0,nSample[iterator-1])
    epsilon = npRnd.normal(0.0,0.7,nSample[iterator-1])
    if (not np.isin(1.0,x)):
        x = np.concatenate([x,[1.0]],axis=0)
        epsilon = np.concatenate([epsilon,npRnd.normal(0.0,0.7,1)],axis=0)
        pass
    if (not np.isin(0.0,x)):
        x = np.concatenate([x,[0.0]],axis=0)
        epsilon = np.concatenate([epsilon,npRnd.normal(0.0,0.7,1)],axis=0)
        pass
    
    print(np.isin(1,x))
    print(np.isin(0,x))
    
    #Generating the values of f0, the real mean function.
    if part=='part1':
        if (thef0Name == 'sigmoid1'):
            f0 = theSigmoid1(x)
        if (thef0Name == 'sigmoid2'):
            f0 = theSigmoid2(x)
        if (thef0Name == 'sigmoid3'):
            f0 = theSigmoid3(x)
        if (thef0Name == 'sigmoidSine1'):
            f0 = theSigmoidSine1(x)
        if (thef0Name == 'sigmoidSine2'):
            f0 = theSigmoidSine2(x)
        if (thef0Name == 'sigmoidSine3'):
            f0 = theSigmoidSine3(x)
            pass
        pass
    
    #Generating the values of f0, the real mean function.
    if part=='part2':
        if (thef0Name == 'fluctuating'):
            f0 = fluctuating(x)
        if (thef0Name == 'nondiff'):
            [x,f0] = nondiff(x)
            pass
        pass
    
    
    #Generating the response values
    y = f0+epsilon
    
    # The depth of the network can be made larger than 1 in the case of ReLU network.
    if activationChoice==1:
        #L = int(np.rint(3*(0.1*np.log(nSample[iterator-1])+1)))
        L = 2
        pass
    
    #Generating the number of hidden nodes in each of the hidden layers of neural networks.
    H = int(np.rint(np.power(nSample[iterator-1],0.4)))
    #H = int(np.rint(3*3*np.power(nSample[iterator-1],0.1)*np.square(0.1*np.log(nSample[iterator-1])+1)))
    print('The Number of Nodes per Hidden Layer = ',H)
    print('The Number of Hidden Layers = ',L)
    nHiddenUnitsFFN = []
    removeProbFFN = []
    removeProbFFN.append(0.0)
    for i in range(1,L+1):
        nHiddenUnitsFFN.append(H)
        removeProbFFN.append(0.0)
        pass
    
    theFFNSeed = 1
    
    print(iterator)
    print(goTraining)
    
    #training and weight calling are here.
    if (activationFunction=='relu'):
        FFN = feedForwardNetwork(nHiddenUnitsFFN,removeProbFFN,x,y,\
                                        1,goTraining,theFolder+'/'+thef0Name+'/FFN for '+thef0Name+' with seed '+str(theFFNSeed)+','+str(L)+' layers, '+str(H)+' nodes per layer, '+str(nSample[iterator-1])+' sample data,'+str(batchSize)+' batches,'+str(epochSize)+' epochs.weights.h5',\
                                        theFFNSeed,batchSize,epochSize,activationFunction)
        
    if (activationFunction=='sigmoid'):
        FFN = feedForwardNetwork(nHiddenUnitsFFN,removeProbFFN,x,y,\
                                        1,goTraining,theFolder+'/'+thef0Name+'/SFN for '+thef0Name+' with seed '+str(theFFNSeed)+','+str(L)+' layers, '+str(H)+' nodes per layer, '+str(nSample[iterator-1])+' sample data,'+str(batchSize)+' batches,'+str(epochSize)+' epochs.weights.h5',\
                                        theFFNSeed,batchSize,epochSize,activationFunction)
    
    # this part is about getting the prediction results from the training data
    if iterator==1:
        FFNValue1 = np.reshape(FFN.predict(x,verbose=0),(x.shape[0],))
        x1 = x
    if iterator==2:
        FFNValue2 = np.reshape(FFN.predict(x,verbose=0),(x.shape[0],))
        x2 = x
    if iterator==3:
        FFNValue3 = np.reshape(FFN.predict(x,verbose=0),(x.shape[0],))
        x3 = x
    if iterator==4:
        FFNValue4 = np.reshape(FFN.predict(x,verbose=0),(x.shape[0],))
        x4 = x
    if iterator==5:
        FFNValue5 = np.reshape(FFN.predict(x,verbose=0),(x.shape[0],))
        x5 = x
    if iterator==6:
        FFNValue6 = np.reshape(FFN.predict(x,verbose=0),(x.shape[0],))
        x6 = x
    
    FFNValue = np.ndarray.flatten(FFN.predict(x,verbose=0))
    rho0square = np.square(f0-FFNValue)
    rho0square = np.average(rho0square)
    mse = np.average(np.square(y-FFNValue))
    
    print('The rho square value = '+str(rho0square))
    print('')
    print('The mean squared error = '+str(mse))
    print('')
    
    #%% this section is meant to get the normality test results of predicted values, draw Q-Q plot of asymptotic normality, curves of f0 and predicted values.
    if asymptoticNormal:
        statAS = []
        for iterAS in range(0,asymptoticNormalSS):
            npRnd.seed(1+iterAS)
            
            #The codes in the 9 lines below are just for technical purposes.
            #They are crucial for coding but not very important for overall consistency/asymptotic properties.
            xAS = npRnd.uniform(0.0,1.0,nSample[iterator-1])
            epsilonAS = npRnd.normal(0.0,0.7,nSample[iterator-1])
            
            # Another variable values of regressors are generated for plotting purpose
            if (not np.isin(1.0,xAS)):
                xAS = np.concatenate([xAS,[1.0]],axis=0)
                epsilonAS = np.concatenate([epsilonAS,npRnd.normal(0.0,0.7,1)],axis=0)
                pass
            
            # Another variable values of regressors are generated for plotting purpose
            if (not np.isin(0.0,xAS)):
                xAS = np.concatenate([xAS,[0.0]],axis=0)
                epsilonAS = np.concatenate([epsilonAS,npRnd.normal(0.0,0.7,1)],axis=0)
                pass
            
            # Another f0 value array is generated for plotting purpose
            if part=='part1':
                if (thef0Name == 'sigmoid1'):
                    f0AS = theSigmoid1(xAS)
                if (thef0Name == 'sigmoid2'):
                    f0AS = theSigmoid2(xAS)
                if (thef0Name == 'sigmoid3'):
                    f0AS = theSigmoid3(xAS)
                if (thef0Name == 'sigmoidSine1'):
                    f0AS = theSigmoidSine1(xAS)
                if (thef0Name == 'sigmoidSine2'):
                    f0AS = theSigmoidSine2(xAS)
                if (thef0Name == 'sigmoidSine3'):
                    f0AS = theSigmoidSine3(xAS)
                    pass
                pass
            
            # Another f0 value array is generated for plotting purpose
            if part=='part2':
                if (thef0Name == 'fluctuating'):
                    f0AS = fluctuating(xAS)
                if (thef0Name == 'nondiff'):
                    [xAS,f0AS] = nondiff(xAS)
                    pass
                pass
            
            # Another response variable value array is generated for plotting purpose
            yAS = f0AS+epsilonAS
            FFNValueAS = np.ndarray.flatten(FFN.predict(xAS,verbose=0))
            
            # Generating values for statistical testing of normality of the predicted value distribution
            statAS1 = np.average(FFNValueAS-f0AS)
            statAS1 = np.sqrt(xAS.shape[0])*statAS1
            #if iterAS<=10:
            #    print(FFNValueAS.shape)
            #    print(f0AS.shape)
            #    print(statAS1)
            #    print('')
            statAS.append(statAS1)
            pass
        
        #Calculating the statistical tests value (K-S, A-D, S-W normal tests)
        npRnd.seed(1)
        statAS = np.asarray(statAS)
        #print(statAS.shape)
        statAS = np.reshape(statAS,(-1,))
        statASaverage = np.average(statAS)
        statASstd = np.std(statAS)
        statAS = np.divide(statAS-statASaverage,statASstd)
        if iterator==1:
            statASAll = statAS
            statASAll = np.reshape(statASAll,(1,-1))
        else:
            statASTemp = statAS
            statASTemp = np.reshape(statASTemp,(1,-1))
            statASAll = np.concatenate((statASAll,statASTemp),axis=0)
        shapiroWilkResults = stats.shapiro(statAS)
        kolmogorovSmirnovResults = stats.ks_2samp(statAS,stats.norm.rvs(loc=0.0,scale=1.0,size=xAS.shape[0]))
        dAgostinoPearsonResults = stats.normaltest(np.reshape(statAS,(-1,)),axis=0)
        
        # printing the values of test statistics
        print('The statistics of Kolmogorov-Smirnov test for sample size '+str(nSample[iterator-1])+' is '+str(kolmogorovSmirnovResults[0]))
        print('The p-value of Kolmogorov-Smirnov test for sample size '+str(nSample[iterator-1])+' is '+str(kolmogorovSmirnovResults[1]))
        print('')
        
        print('The statistics of Shapiro-Wilk test for sample size '+str(nSample[iterator-1])+' is '+str(shapiroWilkResults[0]))
        print('The p-value of Shapiro-Wilk test for sample size '+str(nSample[iterator-1])+' is '+str(shapiroWilkResults[1]))
        print('')
        
        print('The statistics of dAgostino-Pearson test for sample size '+str(nSample[iterator-1])+' is '+str(dAgostinoPearsonResults[0]))
        print('The p-value of dAgostino-Pearson test for sample size '+str(nSample[iterator-1])+' is '+str(dAgostinoPearsonResults[1]))
        print('')
        pass
    
    pass

#%% The Plotting Part
    

x = np.reshape(x,(-1,1))

stepLength = 100000
xPlot = np.arange(0.0,1.0,1.0/stepLength)

f0Plot = interpolate.griddata(x,f0,xPlot,method='cubic')

for iterator in range(1,iterationRange):
    
    if iterator==1:
        FFNValuePlot1 = interpolate.griddata(x1,FFNValue1,xPlot,method='cubic')
    if iterator==2:
        FFNValuePlot2 = interpolate.griddata(x2,FFNValue2,xPlot,method='cubic')
    if iterator==3:
        FFNValuePlot3 = interpolate.griddata(x3,FFNValue3,xPlot,method='cubic')
    if iterator==4:
        FFNValuePlot4 = interpolate.griddata(x4,FFNValue4,xPlot,method='cubic')
    if iterator==5:
        FFNValuePlot5 = interpolate.griddata(x5,FFNValue5,xPlot,method='cubic')
    if iterator==6:
        FFNValuePlot6 = interpolate.griddata(x6,FFNValue6,xPlot,method='cubic')
    
    pass

# This part of the code is for the plotting of the predicted values curves and the real f0 function curve.
plt.close('all')
plt.figure(1)
if activationChoice==1:
    plt.plot(xPlot,f0Plot,color=(0,0,0),label=r'$f_{0}$')
    plt.plot(xPlot,FFNValuePlot1,marker='o',markevery=5000,color=(1,204/255,229/255),label=nSample[1-1])
    plt.plot(xPlot,FFNValuePlot2,marker='o',markevery=5000,color=(1,153/255,1),label=nSample[2-1])
    plt.plot(xPlot,FFNValuePlot3,marker='o',markevery=5000,color=(128/255,1,0),label=nSample[3-1])
    plt.plot(xPlot,FFNValuePlot4,marker='o',markevery=5000,color=(0,204/255,0),label=nSample[4-1])
    if iterationRange==6:
        plt.plot(xPlot,FFNValuePlot5,marker='o',markevery=5000,color=(0,0,1),label=nSample[5-1])
    if iterationRange==7:
        plt.plot(xPlot,FFNValuePlot5,marker='o',markevery=5000,color=(0,0,1),label=nSample[5-1])
        plt.plot(xPlot,FFNValuePlot6,marker='o',markevery=5000,color=(0,76/255,153/255),label=nSample[6-1])
        pass
if activationChoice==2:
    plt.plot(xPlot,f0Plot,color=(0,0,0),label=r'$f_{0}$')
    plt.plot(xPlot,FFNValuePlot1,marker='x',markevery=5000,color=(1,204/255,229/255),label=nSample[1-1])
    plt.plot(xPlot,FFNValuePlot2,marker='x',markevery=5000,color=(1,153/255,1),label=nSample[2-1])
    plt.plot(xPlot,FFNValuePlot3,marker='x',markevery=5000,color=(128/255,1,0),label=nSample[3-1])
    plt.plot(xPlot,FFNValuePlot4,marker='x',markevery=5000,color=(0,204/255,0),label=nSample[4-1])
    if iterationRange==6:
        plt.plot(xPlot,FFNValuePlot5,marker='o',markevery=5000,color=(0,0,1),label=nSample[5-1])
    if iterationRange==7:
        plt.plot(xPlot,FFNValuePlot5,marker='x',markevery=5000,color=(0,0,1),label=nSample[5-1])
        plt.plot(xPlot,FFNValuePlot6,marker='x',markevery=5000,color=(0,76/255,153/255),label=nSample[6-1])
        pass
plt.legend(loc='upper right')
if activationChoice==1:
    plt.title('ReLU Estimation')
if activationChoice==2:
    plt.title('Sigmoid Estimation')
plt.xlabel('x')
plt.ylabel('value')
plt.show()

#%% This part of the codes is designed for drawing Q-Q plots of asymptotic normality.

if asymptoticNormal:
    for iterAS in range(1,int(np.rint(statASAll.shape[0]))+1):
        statAS = statASAll[iterAS-1,:]
        statAS = np.reshape(statAS,(-1,))
        
        #finding quantiles of the predicted value distribution and the related normal distribution
        numQuantile = 100
        rangeQuantile = 1.0/numQuantile
        quantiles = np.linspace(rangeQuantile,1.0,num=numQuantile)
        quantileNorm = stats.norm.ppf(quantiles)
        quantileStat = np.quantile(statAS,quantiles,axis=0)
        
        xLine = np.linspace(-3.0,3.0,num=100000)
        plt.figure(1+iterAS)
        
        #This part is meant for the plotting of the Q-Q plot based on the sample size.
        plt.plot(xLine,xLine,color=(0,0,0))
        if iterAS==1:
            plt.scatter(quantileNorm,quantileStat,s=None,c=(1,0,0),marker='x')
            plt.title('Sample Size = 2,000')
            plt.xlabel('Theoretical Quantile')
            plt.ylabel('Sample Quantile')
            pass
        if iterAS==2:
            plt.scatter(quantileNorm,quantileStat,s=None,c=(204/255,0,102/255),marker='x')
            plt.title('Sample Size = 5,000')
            plt.xlabel('Theoretical Quantile')
            plt.ylabel('Sample Quantile')
            pass
        if iterAS==3:
            plt.scatter(quantileNorm,quantileStat,s=None,c=(153/255,76/255,0),marker='x')
            plt.title('Sample Size = 20,000')
            plt.xlabel('Theoretical Quantile')
            plt.ylabel('Sample Quantile')
            pass
        if iterAS==4:
            plt.scatter(quantileNorm,quantileStat,s=None,c=(76/255,153/255,0),marker='x')
            plt.title('Sample Size = 50,000')
            plt.xlabel('Theoretical Quantile')
            plt.ylabel('Sample Quantile')
            pass
        if iterAS==5:
            plt.scatter(quantileNorm,quantileStat,s=None,c=(0,0,1),marker='x')
            plt.title('Sample Size = 200,000')
            plt.xlabel('Theoretical Quantile')
            plt.ylabel('Sample Quantile')
            pass
        if iterAS==6:
            plt.scatter(quantileNorm,quantileStat,s=None,c=(0,76/255,153/255),marker='x')
            plt.title('Sample Size = 500,000')
            plt.xlabel('Theoretical Quantile')
            plt.ylabel('Sample Quantile')
            pass
        plt.show()
        pass



